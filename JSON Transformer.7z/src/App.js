import React from 'react';
import JSONTransformer from './components/JSONTransformer';

function App() {
  return (
    <div className="App">
      <JSONTransformer />
    </div>
  );
}

export default App;
