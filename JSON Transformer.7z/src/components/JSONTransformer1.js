import { useState } from "react";
import "./JSONTransformer.css";

// Custom object mapping function
function customMapObject(source, mappings) {
  const result = {};
  
  Object.keys(mappings).forEach(sourcePath => {
    const targetPath = mappings[sourcePath];
    
    // Split the paths into segments
    const sourceSegments = sourcePath.split('.');
    const targetSegments = targetPath.split('.');
    
    // Get value from source object
    let sourceValue = source;
    for (const segment of sourceSegments) {
      if (sourceValue === undefined || sourceValue === null) break;
      sourceValue = sourceValue[segment];
    }
    
    // If value is undefined, don't set anything
    if (sourceValue === undefined) return;
    
    // Set value in target object
    let targetObj = result;
    for (let i = 0; i < targetSegments.length; i++) {
      const segment = targetSegments[i];
      
      // If we're at the last segment, set the value
      if (i === targetSegments.length - 1) {
        targetObj[segment] = sourceValue;
      } else {
        // Create nested object if it doesn't exist
        if (!targetObj[segment]) {
          targetObj[segment] = {};
        }
        targetObj = targetObj[segment];
      }
    }
  });
  
  return result;
}

export default function JSONTransformer1() {
  const [inputJSON, setInputJSON] = useState('{\n  "name": "John Doe",\n  "details": {\n    "age": 30,\n    "email": "john@example.com"\n  },\n  "roles": ["admin", "user"]\n}');
  
  const [mapConfig, setMapConfig] = useState('{\n  "name": "fullName",\n  "details.age": "userAge",\n  "details.email": "contactInfo.email",\n  "roles": "permissions"\n}');
  
  const [outputJSON, setOutputJSON] = useState('');
  const [error, setError] = useState('');

  const handleTransform = () => {
    try {
      const sourceObject = JSON.parse(inputJSON);
      const mappingConfig = JSON.parse(mapConfig);
      
      const result = customMapObject(sourceObject, mappingConfig);
      setOutputJSON(JSON.stringify(result, null, 2));
      setError('');
    } catch (err) {
      setError(`Error: ${err.message}`);
      setOutputJSON('');
    }
  };

  return (
    <div className="transformer-container">
      <h1 className="transformer-title">JSON Transformer</h1>
      
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      <div className="main-content">
        <div className="left-panel">
          <div className="input-row">
            <div className="input-section">
              <h2 className="section-title">Input JSON</h2>
              <textarea
                className="textarea"
                value={inputJSON}
                onChange={(e) => setInputJSON(e.target.value)}
                placeholder="Paste your source JSON here"
              />
            </div>
            
            <div className="input-section">
              <h2 className="section-title">Mapping Configuration</h2>
              <textarea
                className="textarea"
                value={mapConfig}
                onChange={(e) => setMapConfig(e.target.value)}
                placeholder="Define your mapping configuration as JSON"
              />
            </div>
          </div>
          
          <div className="transform-button-container">
            <button
              onClick={handleTransform}
              className="transform-button"
            >
              Transform ↓
            </button>
          </div>
        </div>
        
        <div className="right-panel">
          <h2 className="section-title">Output JSON</h2>
          <textarea
            className="textarea"
            value={outputJSON}
            readOnly
            placeholder="Transformed JSON will appear here"
          />
        </div>
      </div>
      
      <div className="instructions">
        <h3 className="instructions-title">How to use:</h3>
        <ol className="instructions-list">
          <li>Enter your source JSON in the left text box</li>
          <li>Define your mapping configuration in the middle text box</li>
          <li>Click the Transform button to see the transformed JSON in the right text box</li>
        </ol>
      </div>
    </div>
  );
}